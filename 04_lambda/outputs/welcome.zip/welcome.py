def hello(event,contest):
    print("Welcome to terraform")